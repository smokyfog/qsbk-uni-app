<?php

namespace app\common\model;

use think\Model;

class UserBind extends Model
{
    //
}
