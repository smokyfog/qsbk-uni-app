<?php

namespace app\common\model;

use think\Model;

class Userinfo extends Model
{
    //
}
