<?php
//000000000000
 exit();?>
think_serialize:a:9:{s:2:"id";i:14;s:8:"username";s:11:"13546021351";s:7:"userpic";N;s:8:"password";s:60:"$2y$10$f1CR90N6Ocstrc42rYj.wuxSBQHLNm3vq1oamQaN2XcSxdDwYR0Ge";s:5:"phone";s:11:"13546021351";s:5:"email";N;s:6:"status";i:1;s:11:"create_time";s:19:"2019-05-04 20:48:57";s:5:"token";s:40:"19d940f6d289d4a2ee78ae6c7fbb2f461dd912bc";}