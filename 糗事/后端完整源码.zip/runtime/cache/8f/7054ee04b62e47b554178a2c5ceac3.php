<?php
//000000000000
 exit();?>
think_serialize:a:9:{s:2:"id";i:13;s:8:"username";s:11:"13450772008";s:7:"userpic";N;s:8:"password";s:0:"";s:5:"phone";s:11:"13450772008";s:5:"email";s:0:"";s:6:"status";i:1;s:11:"create_time";s:19:"2019-05-02 17:40:13";s:5:"token";s:40:"ddf1d460b5fb60856884338ece1b4d6e1f1c1b33";}