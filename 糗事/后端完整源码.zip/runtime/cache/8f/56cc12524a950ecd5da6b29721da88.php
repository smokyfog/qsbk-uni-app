<?php
//000000007200
 exit();?>
think_serialize:a:8:{s:2:"id";i:1;s:4:"type";s:6:"weixin";s:6:"openid";s:28:"oRrdQt3HS3Ns2TFCVLMOyxbR9DcM";s:7:"user_id";i:12;s:8:"nickname";s:6:"楚绵";s:9:"avatarurl";s:131:"http://thirdwx.qlogo.cn/mmopen/vi_32/WiaWkkJjnG4WhI2KERDGPanF9GlNM3SWDTibibKEuHru1Jrd4pfGwialjn5tTCVLvEOq8RnZ8QmqkxyNAYXtuuGcBg/132";s:10:"expires_in";s:4:"7200";s:5:"token";s:40:"e537194a0f6055061aadb57c1ac1719ed945172c";}