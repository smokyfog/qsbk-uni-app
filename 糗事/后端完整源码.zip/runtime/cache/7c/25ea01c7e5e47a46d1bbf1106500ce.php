<?php
//000000000000
 exit();?>
think_serialize:a:7:{s:8:"username";s:11:"13546021351";s:5:"phone";s:11:"13546021351";s:8:"password";s:60:"$2y$10$f1CR90N6Ocstrc42rYj.wuxSBQHLNm3vq1oamQaN2XcSxdDwYR0Ge";s:11:"create_time";s:19:"2019-05-04 20:48:57";s:11:"update_time";s:19:"2019-05-04 20:48:57";s:2:"id";s:2:"14";s:5:"token";s:40:"af2e238f974a41bd8819dccdcd0d28dfceff4080";}