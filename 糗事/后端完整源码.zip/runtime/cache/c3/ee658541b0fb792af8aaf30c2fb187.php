<?php
//000000007200
 exit();?>
think_serialize:a:8:{s:2:"id";i:4;s:4:"type";s:6:"weixin";s:6:"openid";s:28:"oU5Yytz7ielo7Xw00LMgZsPeSDkQ";s:7:"user_id";i:0;s:8:"nickname";s:9:"楚绵222";s:9:"avatarurl";s:131:"http://thirdwx.qlogo.cn/mmopen/vi_32/WiaWkkJjnG4WhI2KERDGPanF9GlNM3SWDTibibKEuHru1Jrd4pfGwialjn5tTCVLvEOq8RnZ8QmqkxyNAYXtuuGcBg/132";s:10:"expires_in";s:4:"7200";s:5:"token";s:40:"adb986b330a3b2c905e89676878cf30fa50ed400";}