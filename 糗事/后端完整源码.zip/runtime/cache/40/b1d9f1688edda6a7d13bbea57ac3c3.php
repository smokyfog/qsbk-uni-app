<?php
//000000000000
 exit();?>
think_serialize:a:10:{s:2:"id";i:15;s:8:"username";s:11:"13450772009";s:7:"userpic";N;s:8:"password";s:0:"";s:5:"phone";s:11:"13450772009";s:5:"email";N;s:6:"status";i:1;s:11:"create_time";s:19:"2019-05-17 15:35:14";s:9:"logintype";s:5:"phone";s:5:"token";s:40:"9c58c77b33ba489e92b70a5a71d16fe142962a79";}