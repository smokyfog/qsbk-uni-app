<?php
//000000000000
 exit();?>
think_serialize:a:10:{s:2:"id";i:13;s:8:"username";s:11:"13450772008";s:7:"userpic";N;s:8:"password";s:0:"";s:5:"phone";s:11:"13450772008";s:5:"email";s:0:"";s:6:"status";i:1;s:11:"create_time";s:19:"2019-05-02 17:40:13";s:9:"logintype";s:5:"phone";s:5:"token";s:40:"4cd36bf70649475ac0cd6fae78250954474a4350";}