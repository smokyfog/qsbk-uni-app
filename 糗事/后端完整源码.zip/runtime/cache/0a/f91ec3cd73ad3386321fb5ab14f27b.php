<?php
//000000000000
 exit();?>
think_serialize:a:10:{s:2:"id";i:14;s:8:"username";s:6:"123456";s:7:"userpic";N;s:8:"password";s:60:"$2y$10$f1CR90N6Ocstrc42rYj.wuxSBQHLNm3vq1oamQaN2XcSxdDwYR0Ge";s:5:"phone";s:11:"13450772011";s:5:"email";s:0:"";s:6:"status";i:1;s:11:"create_time";s:19:"2019-05-04 20:48:57";s:9:"logintype";s:8:"username";s:5:"token";s:40:"3735fc9eb2da38a0adc96aefa76ab4650792afb8";}