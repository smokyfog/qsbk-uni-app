<?php
//000000000000
 exit();?>
think_serialize:a:10:{s:2:"id";i:65;s:8:"username";s:11:"13546121236";s:7:"userpic";N;s:8:"password";s:0:"";s:5:"phone";s:11:"13546121236";s:5:"email";s:10:"599@qq.com";s:6:"status";i:1;s:11:"create_time";i:1562308210;s:9:"logintype";s:5:"phone";s:5:"token";s:40:"9af04c4a9e1d32498a8e4fd942caf8c9d72dccd6";}