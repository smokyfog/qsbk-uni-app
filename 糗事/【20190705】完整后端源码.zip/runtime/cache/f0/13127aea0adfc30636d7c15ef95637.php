<?php
//000000000000
 exit();?>
think_serialize:a:7:{s:8:"username";s:11:"13636523215";s:5:"phone";s:11:"13636523215";s:11:"create_time";i:1562148589;s:11:"update_time";i:1562148589;s:2:"id";s:2:"60";s:9:"logintype";s:5:"phone";s:5:"token";s:40:"96667ef372e79fe4e01b804f81cd9d21d9aff1f2";}