<?php
//000000007200
 exit();?>
think_serialize:a:9:{s:4:"type";s:6:"weixin";s:6:"openid";s:28:"oU5Yyt88hfsY8cRC8-GH0kU-JItw";s:8:"nickname";s:6:"飞狐";s:9:"avatarurl";s:130:"http://thirdwx.qlogo.cn/mmopen/vi_32/hmFBd13lhAbe4LWFJjhyiccjiclNca3qlqFYlbeE2PcCetJj8LHHRrYmvqY51uTV2vUybchBiaJNcw20JsBdWEUJQ/132";s:2:"id";s:2:"32";s:7:"user_id";i:0;s:10:"expires_in";s:4:"7200";s:9:"logintype";s:6:"weixin";s:5:"token";s:40:"1e1c61a78a442a84b67de84c6615251f0d5716a6";}