<?php
//000001000000
 exit();?>
think_serialize:a:9:{s:4:"type";s:6:"alipay";s:6:"openid";s:32:"20880078629513482424992351411414";s:8:"nickname";s:6:"楚绵";s:9:"avatarurl";s:62:"http://tfs.alipayobjects.com/images/partner/T1MmVeXcdgXXXXXXXX";s:2:"id";s:2:"45";s:7:"user_id";i:0;s:10:"expires_in";i:1000000;s:9:"logintype";s:6:"alipay";s:5:"token";s:40:"ee1c0ab130a891df3059a8be917cf381bb7ad1da";}