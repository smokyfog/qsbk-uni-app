<?php
//000000000000
 exit();?>
think_serialize:a:7:{s:8:"username";s:11:"13143592342";s:5:"phone";s:11:"13143592342";s:11:"create_time";i:1561914631;s:11:"update_time";i:1561914631;s:2:"id";s:2:"56";s:9:"logintype";s:5:"phone";s:5:"token";s:40:"8c6e38ce5adaa129dc2049655629ce615f761912";}