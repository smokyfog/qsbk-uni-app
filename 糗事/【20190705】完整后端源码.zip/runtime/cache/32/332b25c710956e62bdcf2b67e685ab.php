<?php
//000000000000
 exit();?>
think_serialize:a:10:{s:2:"id";i:18;s:8:"username";s:11:"13450772013";s:7:"userpic";N;s:8:"password";s:60:"$2y$10$9.KtKNdViCzg7UEeBooZNuxoNBufcwBJaQwV7g6e2gsCnCJEPeHyK";s:5:"phone";s:11:"13450772013";s:5:"email";N;s:6:"status";i:1;s:11:"create_time";i:1559474168;s:9:"logintype";s:5:"phone";s:5:"token";s:40:"4eb3d02cdf01dd163de386380be70b72902afaad";}