<?php
//000001000000
 exit();?>
think_serialize:a:9:{s:2:"id";i:35;s:4:"type";s:6:"weixin";s:6:"openid";s:28:"ojseu4mG6inpuyLiQPooZMfALaNI";s:7:"user_id";i:0;s:8:"nickname";s:6:"楚绵";s:9:"avatarurl";s:125:"https://wx.qlogo.cn/mmopen/vi_32/EFzFp8ZLXDoJWh6uzqC6jnBhgSr8mnVStcKsuzRNmOmK4vIqvsiaz7rd9xHmicx2JkkryxG3HUexuzWrsW8lQ73Q/132";s:9:"logintype";s:6:"weixin";s:10:"expires_in";i:1000000;s:5:"token";s:40:"3b19aad052cd685473a69e4eca50d25f0ce9cc0c";}