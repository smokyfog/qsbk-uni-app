<?php
//000007776000
 exit();?>
think_serialize:a:9:{s:2:"id";i:36;s:4:"type";s:2:"qq";s:6:"openid";s:32:"CC125D0AF8CB544D530158BFAD669DD3";s:7:"user_id";i:52;s:8:"nickname";s:12:"西門掃雪";s:9:"avatarurl";s:74:"http://qzapp.qlogo.cn/qzapp/1104455702/CC125D0AF8CB544D530158BFAD669DD3/30";s:9:"logintype";s:2:"qq";s:10:"expires_in";s:7:"7776000";s:5:"token";s:40:"29c26885c5da4ef1af0f7046a239d86314a4e0ae";}