<?php
//000001000000
 exit();?>
think_serialize:a:9:{s:2:"id";i:45;s:4:"type";s:6:"alipay";s:6:"openid";s:32:"20880078629513482424992351411414";s:7:"user_id";i:0;s:8:"nickname";s:6:"楚绵";s:9:"avatarurl";s:62:"http://tfs.alipayobjects.com/images/partner/T1MmVeXcdgXXXXXXXX";s:9:"logintype";s:6:"alipay";s:10:"expires_in";i:1000000;s:5:"token";s:40:"8041360d731f4eb85f9babd6fcb3fd39445b01cf";}