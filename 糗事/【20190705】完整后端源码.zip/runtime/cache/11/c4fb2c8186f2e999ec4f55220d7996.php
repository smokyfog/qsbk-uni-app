<?php
//000000000000
 exit();?>
think_serialize:a:10:{s:2:"id";i:12;s:8:"username";s:7:"测试1";s:7:"userpic";s:77:"https://douyinzcmcss.oss-cn-shenzhen.aliyuncs.com/shengchengqi/userpic1/2.jpg";s:8:"password";s:60:"$2y$10$04f9Ay2fQPKr1pEFA0KMcedx7mKXeZn01iTk7Opw39TwFveoU3q/W";s:5:"phone";s:11:"13450772007";s:5:"email";s:11:"1236@qq.com";s:6:"status";i:1;s:11:"create_time";i:1556431201;s:9:"logintype";s:5:"phone";s:5:"token";s:40:"e509d93756e77979e71263cd3f729df05f4d07c2";}