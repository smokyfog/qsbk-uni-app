<?php
//000000000000
 exit();?>
think_serialize:a:7:{s:8:"username";s:11:"13546141235";s:5:"phone";s:11:"13546141235";s:11:"create_time";i:1561702296;s:11:"update_time";i:1561702296;s:2:"id";s:2:"48";s:9:"logintype";s:5:"phone";s:5:"token";s:40:"fc8e5a05927450b354267f2876681348f57d4173";}