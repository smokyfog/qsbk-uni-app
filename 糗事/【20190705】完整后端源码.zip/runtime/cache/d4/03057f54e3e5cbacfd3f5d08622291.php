<?php
//000000000000
 exit();?>
think_serialize:a:10:{s:2:"id";i:59;s:8:"username";s:9:"柠檬树";s:7:"userpic";s:80:"https://ceshi2.dishait.cn//uploads/20190703/bcada35dcf3896a770e6408fc16fd857.jpg";s:8:"password";s:60:"$2y$10$If63qe2fybnR9L7xqLGtyO1FtThrBxquU6XYPdjyjLMgWxL8JlHdK";s:5:"phone";s:11:"15827301112";s:5:"email";N;s:6:"status";i:1;s:11:"create_time";i:1562139266;s:9:"logintype";s:5:"phone";s:5:"token";s:40:"602486ef222c4ab5c5954744ebb3afb3a00df6e0";}